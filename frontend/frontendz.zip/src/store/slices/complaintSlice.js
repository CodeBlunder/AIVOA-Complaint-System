// src/store/slices/complaintSlice.js
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../services/api';

// Async Thunks
export const fetchComplaints = createAsyncThunk(
  'complaints/fetchAll',
  async () => {
    const response = await api.get('/complaints/');
    return response.data;
  }
);

export const createComplaint = createAsyncThunk(
  'complaints/create',
  async (data) => {
    const response = await api.post('/complaints/', data);
    return response.data;
  }
);

export const updateComplaint = createAsyncThunk(
  'complaints/update',
  async ({ id, data }) => {
    const response = await api.put(`/complaints/${id}`, data);
    return response.data;
  }
);

const complaintSlice = createSlice({
  name: 'complaints',
  initialState: {
    items: [],
    currentComplaint: null,
    loading: false,
    error: null,
  },
  reducers: {
    setCurrentComplaint: (state, action) => {
      state.currentComplaint = action.payload;
    },
    updateFormField: (state, action) => {
      const { field, value } = action.payload;
      if (state.currentComplaint) {
        state.currentComplaint[field] = value;
      }
    },
    setFormData: (state, action) => {
      state.currentComplaint = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchComplaints.pending, (state) => { state.loading = true; })
      .addCase(fetchComplaints.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(createComplaint.fulfilled, (state, action) => {
        state.items.unshift(action.payload);
        state.currentComplaint = action.payload;
      })
      .addCase(updateComplaint.fulfilled, (state, action) => {
        const idx = state.items.findIndex(c => c.id === action.payload.id);
        if (idx !== -1) state.items[idx] = action.payload;
        state.currentComplaint = action.payload;
      });
  }
});

export const { setCurrentComplaint, updateFormField, setFormData } = complaintSlice.actions;
export default complaintSlice.reducer;