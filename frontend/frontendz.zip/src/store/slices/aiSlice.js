// src/store/slices/aiSlice.js
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../services/api';

export const runLogAgent = createAsyncThunk(
  'ai/logComplaint',
  async (prompt) => {
    const response = await api.post(`/ai/log-complaint?prompt=${encodeURIComponent(prompt)}`);
    return response.data;
  }
);

export const runEditAgent = createAsyncThunk(
  'ai/editComplaint',
  async ({ complaintId, instruction, currentData }) => {
    const response = await api.post(
      `/ai/edit-complaint?complaint_id=${complaintId}&edit_instruction=${encodeURIComponent(instruction)}`,
      currentData
    );
    return response.data;
  }
);

export const runExtractAgent = createAsyncThunk(
  'ai/extractDocument',
  async (formData) => {
    const response = await api.post('/ai/extract-document', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
    return response.data;
  }
);

const aiSlice = createSlice({
  name: 'ai',
  initialState: {
    loading: false,
    riskAssessment: null,
    processingNotes: [],
    error: null,
    lastAction: null,
  },
  reducers: {
    clearAIState: (state) => {
      state.riskAssessment = null;
      state.error = null;
      state.processingNotes = [];
    }
  },
  extraReducers: (builder) => {
    const handlePending = (state) => { state.loading = true; state.error = null; };
    const handleFulfilled = (state, action) => {
      state.loading = false;
      state.riskAssessment = action.payload.risk_assessment;
      state.processingNotes = action.payload.processing_notes || [];
    };
    const handleRejected = (state, action) => {
      state.loading = false;
      state.error = action.error.message;
    };

    builder
      .addCase(runLogAgent.pending, handlePending)
      .addCase(runLogAgent.fulfilled, handleFulfilled)
      .addCase(runLogAgent.rejected, handleRejected)
      .addCase(runEditAgent.pending, handlePending)
      .addCase(runEditAgent.fulfilled, handleFulfilled)
      .addCase(runEditAgent.rejected, handleRejected)
      .addCase(runExtractAgent.pending, handlePending)
      .addCase(runExtractAgent.fulfilled, handleFulfilled)
      .addCase(runExtractAgent.rejected, handleRejected);
  }
});

export const { clearAIState } = aiSlice.actions;
export default aiSlice.reducer;