// src/components/Complaint/ComplaintForm.jsx
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { updateFormField } from '../../store/slices/complaintSlice';
import { createComplaint, updateComplaint } from '../../store/slices/complaintSlice';
import toast from 'react-hot-toast';

const CATEGORIES = ['Quality', 'Packaging', 'Efficacy', 'Safety', 'Labeling', 'Other'];
const SEVERITIES = ['Critical', 'Major', 'Minor'];
const STATUSES = ['Open', 'Under Investigation', 'Pending CAPA', 'Closed'];

export default function ComplaintForm({ isEdit = false }) {
  const dispatch = useDispatch();
  const form = useSelector(s => s.complaints.currentComplaint) || {};

  const handleChange = (field, value) => {
    dispatch(updateFormField({ field, value }));
  };

  const handleSave = async () => {
    try {
      if (isEdit && form.id) {
        await dispatch(updateComplaint({ id: form.id, data: form })).unwrap();
        toast.success('Complaint updated successfully!');
      } else {
        await dispatch(createComplaint(form)).unwrap();
        toast.success('Complaint logged successfully!');
      }
    } catch (err) {
      toast.error('Failed to save complaint.');
    }
  };

  const Field = ({ label, field, type = 'text', options = null }) => (
    <div>
      <label className="block text-xs font-medium text-gray-500 mb-1">{label}</label>
      {options ? (
        <select
          value={form[field] || ''}
          onChange={e => handleChange(field, e.target.value)}
          className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="">Select...</option>
          {options.map(o => <option key={o} value={o}>{o}</option>)}
        </select>
      ) : type === 'textarea' ? (
        <textarea
          value={form[field] || ''}
          onChange={e => handleChange(field, e.target.value)}
          className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 h-24 resize-none"
        />
      ) : (
        <input
          type={type}
          value={form[field] || ''}
          onChange={e => handleChange(field, e.target.value)}
          className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      )}
    </div>
  );

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-lg font-semibold text-gray-900">
          {isEdit ? `Edit Complaint — ${form.complaint_number || ''}` : 'Log Customer Complaint'}
        </h2>
        {form.complaint_number && (
          <span className="text-sm text-gray-400 font-mono">{form.complaint_number}</span>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Section: Complainant */}
        <div className="col-span-2">
          <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-3">
            Complainant Information
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Customer Name" field="complainant_name" />
            <Field label="Company" field="complainant_company" />
            <Field label="Email" field="complainant_email" type="email" />
            <Field label="Phone" field="complainant_phone" />
          </div>
        </div>

        {/* Section: Product */}
        <div className="col-span-2">
          <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-3">
            Product Information
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Product Name" field="product_name" />
            <Field label="Batch/Lot Number" field="batch_number" />
            <Field label="Manufacturing Date" field="manufacturing_date" type="date" />
            <Field label="Expiry Date" field="expiry_date" type="date" />
            <Field label="Quantity Affected" field="quantity_affected" />
            <Field label="Date Received" field="date_received" type="date" />
          </div>
        </div>

        {/* Section: Complaint Details */}
        <div className="col-span-2">
          <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-3">
            Complaint Details
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Category" field="category" options={CATEGORIES} />
            <Field label="Severity" field="severity" options={SEVERITIES} />
            <div className="col-span-2">
              <Field label="Description" field="description" type="textarea" />
            </div>
          </div>
        </div>

        {/* Section: Assignment */}
        <div className="col-span-2">
          <div className="grid grid-cols-2 gap-4">
            <Field label="Assigned To" field="assigned_to" />
            <Field label="Status" field="status" options={STATUSES} />
          </div>
        </div>
      </div>

      <div className="mt-6 flex gap-3 justify-end">
        <button
          onClick={() => {/* clear form */}}
          className="px-4 py-2 border border-gray-200 rounded-lg text-sm font-medium text-gray-600 hover:bg-gray-50"
        >
          Clear
        </button>
        <button
          onClick={handleSave}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700"
        >
          {isEdit ? 'Update Complaint' : 'Save Complaint'}
        </button>
      </div>
    </div>
  );
}