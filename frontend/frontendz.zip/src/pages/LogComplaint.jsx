import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { setFormData } from '../store/slices/complaintSlice';
import { clearAIState } from '../store/slices/aiSlice';
import ComplaintForm from '../components/Complaint/ComplaintForm';
import AICopilot from '../components/AITools/AICopilot';
import DocumentUpload from '../components/AITools/DocumentUpload';
import RiskAssessment from '../components/AITools/RiskAssessment';
import { Wand2, Upload, FileText } from 'lucide-react';

/**
 * Log Complaint page.
 * Layout: left = AI tools panel, right = complaint form.
 * The AI tools auto-fill the form on the right.
 */
export default function LogComplaint() {
  const dispatch = useDispatch();

  // Clear any leftover state from previous sessions when page loads
  useEffect(() => {
    dispatch(setFormData({}));
    dispatch(clearAIState());
  }, [dispatch]);

  return (
    <div className="flex gap-6 h-full">
      {/* ── LEFT PANEL: AI Tools ──────────────────────────────── */}
      <div className="w-80 shrink-0 space-y-4 overflow-y-auto pr-1">
        {/* Section label */}
        <div className="flex items-center gap-2">
          <Wand2 size={15} className="text-blue-500" />
          <h2 className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            AI Tools
          </h2>
        </div>

        {/* Tool 1: AI Copilot – type a prompt */}
        <AICopilot mode="log" />

        {/* Divider */}
        <div className="flex items-center gap-2">
          <div className="flex-1 h-px bg-slate-200" />
          <span className="text-xs text-slate-400">or</span>
          <div className="flex-1 h-px bg-slate-200" />
        </div>

        {/* Tool 2: Document Upload */}
        <DocumentUpload />

        {/* Tool 3: Risk Assessment panel (appears after AI processing) */}
        <div className="flex items-center gap-2 mt-2">
          <FileText size={15} className="text-blue-500" />
          <h2 className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            AI Copilot Risk Assessment
          </h2>
        </div>
        <RiskAssessment />
      </div>

      {/* ── RIGHT PANEL: Complaint Form ───────────────────────── */}
      <div className="flex-1 overflow-y-auto">
        <ComplaintForm isEdit={false} />
      </div>
    </div>
  );
}