/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'sans-serif'],  // Mandatory: Google Inter
      },
      colors: {
        primary: {
          50: '#eff6ff',
          500: '#3b82f6',
          600: '#2563eb',
          700: '#1d4ed8',
        },
        pharma: {
          green: '#10b981',
          red: '#ef4444',
          yellow: '#f59e0b',
        }
      }
    },
  },
  plugins: [],
}